import React, { useState } from "react";

function EnrollStudent({ addData }) {
  const [formData, setformData] = useState({
    name: "",
    email: "",
    website: "",

    gender: "",
    languages: [],
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setformData((prevFormData) => {
        if (checked) {
          return {
            ...prevFormData,
            languages: [...prevFormData.languages, value],
          };
        } else {
          return {
            ...prevFormData,
            languages: prevFormData.languages.filter((lang) => lang !== value),
          };
        }
      });
    } else {
      setformData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addData(formData);
    setformData({
      name: "",
      email: "",
      website: "",

      gender: "",
      languages: [],
    });
  };

  const handleCancel = () => {
    setformData({
      name: "",
      email: "",
      website: "",

      gender: "",
      languages: [],
    });
  };
  return (
    <>
      <form onSubmit={handleSubmit}>
        <label htmlFor="">Name:</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <br />
        <label htmlFor="">Email:</label>
        <input
          type="text"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />{" "}
        <br />
        <label htmlFor="">Website:</label>
        <input
          type="text"
          name="website"
          value={formData.website}
          onChange={handleChange}
        />{" "}
        <br />
        <br />
        <label htmlFor="">Gender:</label>
        <input
          type="radio"
          name="gender"
          value="Female"
          checked={formData.gender === "Female"}
          onChange={handleChange}
        />
        <label htmlFor="">Female</label>
        <input
          type="radio"
          name="gender"
          value="Male"
          checked={formData.gender === "Male"}
          onChange={handleChange}
        />
        <label htmlFor="">Male</label>
        <input
          type="radio"
          name="gender"
          value="Other"
          checked={formData.gender === "Other"}
          onChange={handleChange}
        />
        <label htmlFor="">Other</label>
        <br />
        <label htmlFor="">Skills:</label>
        <input
          type="checkbox"
          name="languages"
          value="HTML"
          checked={formData.languages.includes("HTML")}
          onChange={handleChange}
        />
        HTML
        <input
          type="checkbox"
          name="languages"
          value="CSS"
          checked={formData.languages.includes("CSS")}
          onChange={handleChange}
        />
        CSS
        <input
          type="checkbox"
          name="languages"
          value="Javascript"
          checked={formData.languages.includes("Javascript")}
          onChange={handleChange}
        />
        Javascript
        <input
          type="checkbox"
          name="languages"
          value="ReactJs"
          checked={formData.languages.includes("  ReactJs")}
          onChange={handleChange}
        />
        ReactJs
        <br />
        <button type="submit" id="enroll">
          Enroll{" "}
        </button>
        <button type="button" id="cancel" onClick={handleCancel}>
          Cancel
        </button>
      </form>
    </>
  );
}

export default EnrollStudent;
