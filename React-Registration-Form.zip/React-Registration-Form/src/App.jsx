import React, { useState } from "react";
import EnrollStudent from "./EnrollStudent";
import DisplayData from "./DisplayData";

import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
function App() {
  const [data, setData] = useState([]);
  const addData = (formData) => {
    setData([...data, formData]);
  };

  return (
    <>
      <h1>Student Enrollment Form</h1>
      <div className="wrap">
        <EnrollStudent addData={addData} />
        <DisplayData data={data} />
      </div>
    </>
  );
}

export default App;
