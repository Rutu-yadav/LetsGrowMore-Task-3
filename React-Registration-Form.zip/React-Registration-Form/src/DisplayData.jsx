import React from "react";

function DisplayData({ data }) {
  return (
    <div className="tablee">
      <table border="1">
        <thead>
          <tr>
            <th className="head">Name</th>
            <th className="head">Email</th>
            <th className="head">Website</th>

            <th className="head">Gender</th>
            <th className="head">Skills</th>
          </tr>
          <tr></tr>
        </thead>

        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <th>{item.name} </th>
              <th>{item.email}</th>
              <th>
                <a href="">{item.website} </a>
              </th>
              <th>{item.gender} </th>
              <th>{item.languages.join(", ")}</th>
              <hr />
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DisplayData;
